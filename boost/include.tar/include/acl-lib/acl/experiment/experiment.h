#ifndef ACL_EXPERIMENT_INCLUDE_H
#define ACL_EXPERIMENT_INCLUDE_H

#ifdef __cplusplus
extern "C" {
#endif

#define	EXPERIMENT	1

#ifdef __cplusplus
}
#endif

#endif
