#ifndef	ACL_THREAD_INCLUDE_H
#define	ACL_THREAD_INCLUDE_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "acl_pthread.h"
#include "acl_pthread_rwlock.h"
#include "acl_pthread_pool.h"
#include "acl_sem.h"

#ifdef	__cplusplus
}
#endif

#endif
