#ifndef	ACL_UNIT_TEST_INCLUDE_H
#define	ACL_UNIT_TEST_INCLUDE_H

# ifdef	__cplusplus
extern  "C" {
# endif

#include "acl_test_struct.h"
#include "acl_test_global.h"
#include "acl_test_var.h"
#include "acl_test_macro.h"

# ifdef	__cplusplus
}
# endif

#endif

