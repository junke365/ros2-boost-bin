#pragma once
#include "acl_cpp/acl_cpp_define.hpp"

namespace acl
{

class ACL_CPP_API InitiateMultipartUploadResult
{
public:
	InitiateMultipartUploadResult();
	~InitiateMultipartUploadResult();

private:
};

} // namespace acl
