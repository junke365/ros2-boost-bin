#pragma once
#include "acl_cpp/acl_cpp_define.hpp"

namespace acl
{

class ACL_CPP_API UploadPartCopyResult
{
public:
	UploadPartCopyResult();
	~UploadPartCopyResult();

private:
};

} // namespace acl
