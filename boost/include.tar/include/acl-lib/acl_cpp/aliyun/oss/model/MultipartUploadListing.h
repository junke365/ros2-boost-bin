#pragma once
#include "acl_cpp/acl_cpp_define.hpp"

namespace acl
{

class ACL_CPP_API MultipartUploadListing
{
public:
	MultipartUploadListing();
	~MultipartUploadListing();

private:
};

} // namespace acl
