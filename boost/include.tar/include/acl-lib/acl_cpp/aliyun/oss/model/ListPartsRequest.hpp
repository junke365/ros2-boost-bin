#pragma once
#include "acl_cpp/acl_cpp_define.hpp"

namespace acl
{

class ACL_CPP_API ListPartsRequest
{
public:
	ListPartsRequest();
	~ListPartsRequest();

private:
};

} // namespace acl
