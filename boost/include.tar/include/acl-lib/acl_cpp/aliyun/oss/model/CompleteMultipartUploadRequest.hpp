#pragma once
#include "acl_cpp/acl_cpp_define.hpp"

namespace acl
{

class ACL_CPP_API CompleteMultipartUploadRequest
{
public:
	CompleteMultipartUploadRequest();
	~CompleteMultipartUploadRequest();

private:
};

} // namespace acl
