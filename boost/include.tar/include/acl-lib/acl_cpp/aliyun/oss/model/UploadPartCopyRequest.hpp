#pragma once
#include "acl_cpp/acl_cpp_define.hpp"

namespace acl
{

class ACL_CPP_API UploadPartCopyRequest
{
public:
	UploadPartCopyRequest();
	~UploadPartCopyRequest();

private:
};

} // namespace acl
