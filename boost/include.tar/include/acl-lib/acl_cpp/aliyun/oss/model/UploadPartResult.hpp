#pragma once
#include "acl_cpp/acl_cpp_define.hpp"

namespace acl
{

class ACL_CPP_API UploadPartResult
{
public:
	UploadPartResult();
	~UploadPartResult();

private:
};

} // namespace acl
