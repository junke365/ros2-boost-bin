#pragma once
#include "acl_cpp/acl_cpp_define.hpp"

namespace acl
{

class ACL_CPP_API CreateBucketRequest
{
public:
	CreateBucketRequest();
	~CreateBucketRequest();

private:
};

} // namespace acl
