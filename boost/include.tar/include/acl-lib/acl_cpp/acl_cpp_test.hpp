#pragma once
#include "acl_cpp_define.hpp"

namespace acl
{
	ACL_CPP_API void test_logger(void);
	ACL_CPP_API void test_snprintf(void);
}

